
#include <iostream>
#include <string>

#include "ClsMainScreen.h"; 





int main()
{

	
	ClsMainScreen::ShowMainScreen(); 


}

